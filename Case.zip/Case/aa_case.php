
<?php

if(!isset($carp)) $carp = '';

echo '<script src="'.$carp.'Build/ODD.js"></script>';
echo '<script src="'.$carp.'BaseData/LoadData.js"></script>';
echo '<script src="'.$carp.'BaseData/LoadsData.js"></script>';

echo '<script src="'.$carp.'BaseData/Mysql.js"></script>';
echo '<script src="'.$carp.'BaseData/dataBase.js"></script>';
echo '<script src="'.$carp.'BaseData/Load_Table.js"></script>';

echo '<script src="'.$carp.'Build/Events_Machine.js"></script>';

echo '<script src="'.$carp.'Build/Params.js"></script>';
echo '<script src="'.$carp.'Build/Box.js"></script>';
echo '<script src="'.$carp.'Build/Grid.js"></script>';
echo '<script src="'.$carp.'Build/Label.js"></script>';
echo '<script src="'.$carp.'Build/Modulo.js"></script>';
echo '<script src="'.$carp.'Build/Modulo_Filter.js"></script>';
echo '<script src="'.$carp.'Build/Table_Grid.js"></script>';
echo '<script src="'.$carp.'Build/Window.js"></script>';
echo '<script src="'.$carp.'Build/ScreenLoad.js"></script>';

echo '<script src="'.$carp.'Build/Form_Body.js"></script>';
echo '<script src="'.$carp.'Build/Form_Data.js"></script>';
echo '<script src="'.$carp.'Build/Form_States.js"></script>';
echo '<script src="'.$carp.'Build/Form_Base.js"></script>';
echo '<script src="'.$carp.'Build/Form_Conection.js"></script>';

echo '<script src="'.$carp.'Build/Form_Table.js"></script>';
echo '<script src="'.$carp.'Build/Form_Modulos.js"></script>';
echo '<script src="'.$carp.'Build/Master.js"></script>';

echo '<script src="'.$carp.'Land/UserLog.js"></script>';
echo '<script src="'.$carp.'Land/Pag_Base.js"></script>';

echo '<script src="'.$carp.'Source/Usefull.js"></script>';
echo '<script src="'.$carp.'Source/Nav.js"></script>';

//echo '<script>const carp="'.$carp.'"</script>';
//echo '<script src="'.$carp.'aa.js"></script>';



 ?>
