
<?php

if(!isset($carp)) $carp = '';

include 'aa_librarys.php';
include 'aa_case.php';

 ?>
