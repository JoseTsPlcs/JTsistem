<?php

require 'Mysql_Conection.php';

echo json_encode($resp);

 ?>
