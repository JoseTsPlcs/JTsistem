
$(document).ready(function() {

  /*new Form_Table({
    ...adm_control,
  });*/

  AdmControlPanel();
  

});
