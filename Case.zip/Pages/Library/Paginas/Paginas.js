
$(document).ready(function() {

  IsLog(function() {

    // var pages = new Pages([[12]]);
    //
    // var form_pages = new Form_Table_Fields(pages.GetDiv(0,0), 'Paginas', sql_log, 2,[
    //   new Field({
    //     etiqueta:{title:'Id', show:true},
    //     cell:{tipe:0},
    //     sql:{table: 2, head: 0},
    //   }),
    //     new Field({
    //       etiqueta:{title:'Pagina', show:true},
    //       cell:{tipe:1},
    //       sql:{table: 2, head: 1},
    //     }),
    //     new Field({
    //       etiqueta:{title:'URL', show:true},
    //       cell:{tipe:1},
    //       sql:{table: 2, head: 2},
    //     }),
    // ], [
    //   {tool: 'filters', show: false, info:[]}
    // ],null,null);

    // var form_usuarios_pages = new Form_Table_Fields(pages.GetDiv(0,3), 'Paginas por Clase', sql_log, 0,[
    //     new Field({
    //       etiqueta:{title:'Usuarios', show:true},
    //       cell:{tipe:0},
    //       sql:{table: 0, head: 1},
    //     }),
    //     new Field({
    //       etiqueta:{title:'Pagina', show:true},
    //       cell:{tipe:0},
    //       sql:{table: 2, head: 1},
    //     }),
    // ], [
    //   {tool: 'filters', show: false, info:[
    //     {title: 'Usuario', tipe: 1, sql:{table: 0, head: 1}},
    //   ]}
    // ],null,{
    //   joins:[
    //     {main:{table:0,head:3},external:{table:3,head:1}},
    //     {main:{table:3,head:1},external:{table:2,head:0}},
    //   ]
    // });


  }, '../../../');

});
