<?php

if(!isset($carp)) $carp = '';

echo '<script src="'.$carp.'Pages/PageStart.js"></script>';

include $carp.'SystemCase/ScriptBase.php';

echo '<script src="'.$carp.'TableForm/Usefull.js"></script>';
echo '<script src="'.$carp.'TableForm/Conection_BaseData.js"></script>';
echo '<script src="'.$carp.'Scripts/Base.js"></script>';
echo '<script src="'.$carp.'Usuarios/Usuarios.js"></script>';


 ?>
