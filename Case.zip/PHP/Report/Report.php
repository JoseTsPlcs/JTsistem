<?php

require '../Conection.php';
include '../Base_Resp.php';

$resp['data'] = array();

$line = array(
  'date' => ,
  'description' => ,
  'metodo' => ,
  'total' => ,
);


echo json_encode($resp);
 ?>
