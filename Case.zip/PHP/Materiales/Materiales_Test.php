<?php

$action = "start";

echo json_encode($action);

 ?>
