<?php

include '../Conection.php';

$products = array(
  'id'=> array(),
  'product' => array(),
  '100g' => array(),
  '250g' => array(),
  '500g' => array(),
  '1kg' => array(),
  '1kg>' => array(),
  '5kg>' => array(),
  'one' => array(),
  'stock' => array()
);


 ?>
