<?php

include '../Conection.php';

$users = array(
  'user' => array(),
  'id' => array()
);

//$clientes['name'] = strtoupper($clientes['name']);

 ?>
