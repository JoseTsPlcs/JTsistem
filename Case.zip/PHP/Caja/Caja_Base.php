<?php

include '../Conection.php';

$info = array('id' => ,'date' => ,'description' => ,'ingreso' => ,'check' => );

 ?>
