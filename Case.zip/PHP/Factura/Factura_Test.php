<?php
include 'Factura_base.php';

echo json_encode($fct);

 ?>
