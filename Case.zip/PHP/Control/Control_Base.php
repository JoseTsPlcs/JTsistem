<?php

include '../Conection.php';

$report = array(

  'nro' => array(),
  'date' => array(),
  'name' => array(),
  'comment' => array(),
  'confirm' => array(),
  'time_a' => array(),
  'time_b' => array(),

  'cancelado' => array(),
  'cajero' => array(),
  'entregado' => array(),
  'metodo' => array(),
  'recoge' => array(),

  'total' => array(),
  'anulado' => array(),
  'armado' => array(),

  'trabajador' => array(),
  'delivery' => array(),
  'zone' => array(),
  'macro' => array()

);

 ?>
