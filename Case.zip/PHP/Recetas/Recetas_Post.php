<?php

$receta = $_POST['receta'];
$tipo = $_POST['tipo'];
$etiqueta = $_POST['etiqueta'];
$precio = $_POST['precio'];
$costo_total = $_POST['costo_total'];

$mercaderia_ids = $_POST['mercaderia_ids'];
$mercaderia_counts = $_POST['mercaderia_counts'];
$mercaderia_costos = $_POST['mercaderia_costos'];

 ?>
