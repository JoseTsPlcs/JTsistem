<?php

include '../Conection.php';

$clientes = array(
  'cliente_id' => array(),
  'name' => array(),
  'dni' => array(),
  'zone_id' => array(),
  'zone' => array(),
  'dir' => array(),
  'ref' => array(),
  'cel' => array(),
  'gps' => array(),
  'metodo' => array(),
  'recoge' => array(),
  'documento' => array(),
);

//$clientes['name'] = strtoupper($clientes['name']);

 ?>
