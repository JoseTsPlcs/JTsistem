<?php
include 'Cliente_base';

echo json_encode($clientes);

 ?>
